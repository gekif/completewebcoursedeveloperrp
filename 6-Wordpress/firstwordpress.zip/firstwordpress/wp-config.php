<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'firstwordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'password');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'APrH6W9(d_l? pbxj)WZ0N_PmsJ0IATE[Zgn_w|Vbm[t+E]8:!IG%+sQ7><[T:0(');
define('SECURE_AUTH_KEY',  'Bv{*ey]3Ata;sooFDzk8>c@}?+^<i)L .Hczc445&L5A6`AUzVVq(PcMT+QmaWu(');
define('LOGGED_IN_KEY',    'mQ%<!wqx3`#_a0nkYT0jh!&F*0i+D;,_3Ng5R2ySSk ektr{MRUVip} rx*]:IQp');
define('NONCE_KEY',        'icp@m&p6(:E=jfL_;8YU}Yin<|qH5iTw=uGTUw%t23<BjS*$_r1QB?/=_EQG[*%l');
define('AUTH_SALT',        'Za6g|[+AIm(CluSqu$.4T3Kgvn ^GfHB7 Da.Quc3}g,l4|1#<A+we[7%3;x bge');
define('SECURE_AUTH_SALT', '|dw7_;4`yzpF 3!x,!r^:qYx]%QsZa7vc7rf%QfZgl}rfdTMewpux9khoEhE`3jE');
define('LOGGED_IN_SALT',   'yHfN)7~r)0fvEu!H3=D1I599Qw^IT_LK<Y, blREkIWh@RrP}]:E7i[!K*<z=luT');
define('NONCE_SALT',       '}6oTTQhIJ%>0ZNo]U7xHi(%APJ+Y1#a>bz8:J%k@TV16*o#*cY;<zhDEhI}xm!e+');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
